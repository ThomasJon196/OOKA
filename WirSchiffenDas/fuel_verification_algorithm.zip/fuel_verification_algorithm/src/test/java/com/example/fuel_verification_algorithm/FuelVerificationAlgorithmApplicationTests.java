package com.example.fuel_verification_algorithm;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FuelVerificationAlgorithmApplicationTests {

	@Test
	void contextLoads() {
	}

}
