package com.example.Motor_Verification_Algorithm;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MotorVerificationAlgorithmApplication {

	public static void main(String[] args) {
		SpringApplication.run(MotorVerificationAlgorithmApplication.class, args);
	}

}
