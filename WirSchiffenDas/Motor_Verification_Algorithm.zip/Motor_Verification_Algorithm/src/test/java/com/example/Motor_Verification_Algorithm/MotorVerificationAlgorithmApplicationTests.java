package com.example.Motor_Verification_Algorithm;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MotorVerificationAlgorithmApplicationTests {

	@Test
	void contextLoads() {
	}

}
