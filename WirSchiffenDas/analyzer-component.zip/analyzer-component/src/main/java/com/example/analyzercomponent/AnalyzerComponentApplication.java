package com.example.analyzercomponent;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AnalyzerComponentApplication {

	public static void main(String[] args) {
		SpringApplication.run(AnalyzerComponentApplication.class, args);
	}

}
