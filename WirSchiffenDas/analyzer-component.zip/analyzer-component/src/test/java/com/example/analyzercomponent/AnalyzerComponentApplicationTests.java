package com.example.analyzercomponent;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AnalyzerComponentApplicationTests {

	@Test
	void contextLoads() {
	}

}
