package com.example.oil_verification_algorithm;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OilVerificationAlgorithmApplication {

	public static void main(String[] args) {
		SpringApplication.run(OilVerificationAlgorithmApplication.class, args);
	}

}
