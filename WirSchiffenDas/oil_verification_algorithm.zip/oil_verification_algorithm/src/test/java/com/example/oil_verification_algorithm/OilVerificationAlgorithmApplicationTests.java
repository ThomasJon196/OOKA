package com.example.oil_verification_algorithm;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OilVerificationAlgorithmApplicationTests {

	@Test
	void contextLoads() {
	}

}
