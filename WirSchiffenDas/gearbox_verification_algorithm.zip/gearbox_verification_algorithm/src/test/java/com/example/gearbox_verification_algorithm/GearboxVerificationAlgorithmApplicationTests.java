package com.example.gearbox_verification_algorithm;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GearboxVerificationAlgorithmApplicationTests {

	@Test
	void contextLoads() {
	}

}
